import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'cart_screen.dart';

class ItemsDetailsScreen extends StatefulWidget {
  const ItemsDetailsScreen({Key? key}) : super(key: key);

  @override
  State<ItemsDetailsScreen> createState() => _ItemsDetailsScreenState();
}

class _ItemsDetailsScreenState extends State<ItemsDetailsScreen> {
  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Scaffold(
      appBar: AppBar(
        leading: Icon(
          Icons.home,
          color: Colors.black,
          size: 25,
        ),
        title: Text(
          "Shopping",
          style: TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.bold,
            color: Colors.black,
          ),
        ),
        actions: [
          Padding(
            padding: EdgeInsets.only(right: 20, top: 17),
            child: FaIcon(
              FontAwesomeIcons.heart,
              color: Colors.red,
            ),
          ),
        ],
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                width: size.width,
                child: Image.asset("assets/purple.png"),

              ),
              SizedBox(height: 20),
              Container(
                margin: EdgeInsets.symmetric(horizontal: 15),
                child: Text(
                  "Nike Men",
                  style: TextStyle(fontSize: 13, color: Colors.grey),
                ),
              ),
              SizedBox(height: 10),
              Container(
                margin: EdgeInsets.symmetric(horizontal: 15, vertical: 10),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      "Retro Purple ",
                      style: TextStyle(
                        fontSize: 25,
                        color: Colors.black,
                      ),
                    ),
                    Text(
                      "\$120",
                      style: TextStyle(
                        fontSize: 25,
                        color: Colors.redAccent,
                      ),
                    ),
                  ],
                ),
              ),
              SizedBox(height: 30),
              Container(
                margin: EdgeInsets.symmetric(horizontal: 15),
                child: Text(
                  "Sizes",
                  style: TextStyle(
                    fontSize: 15,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
              SizedBox(height: 20),
              SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                child: Row(
                  children: [
                    SizedBox(width: 8),
                    _makeSizeButton("US7", false),
                    SizedBox(width: 8),
                    _makeSizeButton("US7.5", true),
                    SizedBox(width: 8),
                    _makeSizeButton("US8", true),
                    SizedBox(width: 8),
                    _makeSizeButton("US8.5", true),
                    SizedBox(width: 8),
                    _makeSizeButton("US9", false),
                    SizedBox(width: 8),
                    _makeSizeButton("US9.5", true),
                    SizedBox(width: 8),
                    _makeSizeButton("US10", true),
                  ],
                ),
              ),
              SizedBox(height: 20),
              Container(
                margin: EdgeInsets.symmetric(horizontal: 15),
                child: Text(
                  "Fast Delivery and Many Payment Options",
                  style: TextStyle(
                    fontSize: 13,
                    color: Colors.grey,
                  ),
                ),
              ),
              SizedBox(height: 30),
              Container(
                margin: EdgeInsets.symmetric(horizontal: 15),
                child: Text(
                  "Description",
                  style: TextStyle(
                    fontSize: 15,
                    fontWeight: FontWeight.w600,
                    color: Colors.black,
                  ),
                ),
              ),
              Container(
                margin: EdgeInsets.symmetric(horizontal: 15),
                child: Text(
                  "Dressed in a Sky J Purple and White color scheme. This offering of the low-top Air Jordan 1 comes constructed in a full leather build with mesh tongues and lining. It features a White base with a light and dark shade of Purple used on the overlays and branded areas. White laces and midsole atop a Purple rubber outsole completes the design.",
                  style: TextStyle(
                    fontSize: 15,
                    fontWeight: FontWeight.w600,
                    color: Colors.black,
                    height: 1.5,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => CartScreen()), // Use your CartScreen.dart
          );
        },
        backgroundColor: Colors.black,
        child: Icon(Icons.shopping_cart),
      ),
    );
  }

  Widget _makeSizeButton(String size, bool available) {
    return Container(
      width: 80,
      height: 30,
      decoration: BoxDecoration(
        color: available ? Colors.white : Colors.grey,
        borderRadius: BorderRadius.circular(30),
        border: Border.all(
          color: Colors.grey,
          width: 0.3,
        ),
      ),
      child: Center(
        child: Text(
          size,
          style: TextStyle(
            fontSize: 15,
            fontWeight: FontWeight.w500,
            color: available ? Colors.black : Colors.white,
          ),
        ),
      ),
    );
  }
}
