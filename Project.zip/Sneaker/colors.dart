import 'package:flutter/material.dart';

class Clrs {
  static final Color kPrimary = Color(0xFF000000);
}
